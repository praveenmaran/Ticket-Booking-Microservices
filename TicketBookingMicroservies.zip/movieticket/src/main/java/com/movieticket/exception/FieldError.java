package com.movieticket.exception;

import java.io.Serializable;

public class FieldError implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5606620106516508177L;
	
	private String field;
	private String error;
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public FieldError(String field, String error) {
		super();
		this.field = field;
		this.error = error;
	}
	public FieldError() {
		super();
	}
	
	 

}
