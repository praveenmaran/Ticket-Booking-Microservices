package com.movieticket.exception;

import org.springframework.http.HttpStatus;

public class MovException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1305852241595798108L;
	
	
	private String message;
	private String code;
	private HttpStatus httpStatus;
	
	MovException(){
		super();
	}
	
	MovException(String message){
		super(message);
		this.message = message;
	}
	
	

	public MovException(String message, HttpStatus httpStatus) {
		super();
		this.message = message;
		this.httpStatus = httpStatus;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

}
