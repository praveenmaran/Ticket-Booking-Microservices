package com.movieticket.exception;

import java.util.stream.Collectors;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@Order(value=Ordered.HIGHEST_PRECEDENCE)
public class RestExceptionHandler extends ResponseEntityExceptionHandler {
	
	
	
	@ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> handleMovException(
    		IllegalArgumentException ex) {
		        ExceptionDTO dto=new ExceptionDTO();
		        dto.setMessage(ex.getMessage());
		        return buildResponseEntity(dto);
	   }
	
	@Override
    public ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {
		        ExceptionDTO dto=new ExceptionDTO();
		        dto.setErrors(ex.getBindingResult().getFieldErrors().stream().map(map->new FieldError(map.getField(),map.getDefaultMessage())).collect(Collectors.toList()));
		        return buildResponseEntity(dto);
	   }

	   private ResponseEntity<Object> buildResponseEntity(ExceptionDTO apiError) {
	       return new ResponseEntity<Object>(apiError,HttpStatus.OK);
	   }
}
