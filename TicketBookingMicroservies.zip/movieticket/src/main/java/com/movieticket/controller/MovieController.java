package com.movieticket.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.movieticket.dto.MovResponse;
import com.movieticket.dto.MovieTicketDTO;
import com.movieticket.entity.MovieDetails;
import com.movieticket.entity.User;
import com.movieticket.exception.MovException;
import com.movieticket.service.MovieService;

@RestController
@RequestMapping("/")
public class MovieController {
	
	@Autowired
	MovieService movieService;
	@PostMapping(value="/user/add",consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<MovResponse> addUser(@RequestBody User user) throws MovException{
		return new ResponseEntity<MovResponse>(movieService.addUser(user),HttpStatus.OK);
	}
	

	@GetMapping(value="/movie/get/all", produces = MediaType.APPLICATION_JSON_VALUE )
	@PreAuthorize("hasAnyAuthority('admin','user')")
	public ResponseEntity<List<MovieDetails>> getMovies() throws MovException{
		List<MovieDetails> movieDetails = movieService.getMovies();
		return new ResponseEntity<List<MovieDetails>>(movieDetails,HttpStatus.OK);
		
	}
	
	@PostMapping(value="/movie/add",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE )
	@PreAuthorize("hasAnyAuthority('admin')")
	public ResponseEntity<MovResponse> addMovie(@RequestBody MovieDetails details) throws MovException{
		MovResponse status =  movieService.addMovie(details);
		return new ResponseEntity<MovResponse>(status,HttpStatus.OK);
		
	}
	
	@PostMapping(value="/movie/ticket/lock",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE )
	@PreAuthorize("hasAnyAuthority('admin','user')")
	public ResponseEntity<MovResponse> ticketBlock(@RequestBody @Valid MovieTicketDTO movieTicketDTO) throws MovException{
		MovResponse status =  movieService.ticketBlock(movieTicketDTO);
		return new ResponseEntity<MovResponse>(status,HttpStatus.OK);
		
	}
	
	@PostMapping(value="/movie/ticket/confirm/{referenceId}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE )
	@PreAuthorize("hasAnyAuthority('admin','user')")
	public ResponseEntity<MovResponse> ticketConfirm(@PathVariable Integer referenceId) throws MovException{
		MovResponse status =  movieService.ticketConfirm(referenceId);
		return new ResponseEntity<MovResponse>(status,HttpStatus.OK);
		
	}


}
