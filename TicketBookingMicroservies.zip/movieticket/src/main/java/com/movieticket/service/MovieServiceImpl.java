package com.movieticket.service;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;

import com.movieticket.dto.MovResponse;
import com.movieticket.dto.MovieTicketDTO;
import com.movieticket.entity.BookedTicket;
import com.movieticket.entity.BookedTicketDetails;
import com.movieticket.entity.MovieDetails;
import com.movieticket.entity.TicketLock;
import com.movieticket.entity.TicketLockDetails;
import com.movieticket.entity.User;
import com.movieticket.exception.MovException;
import com.movieticket.repository.BookedTicketRepo;
import com.movieticket.repository.MovieDetailsRepo;
import com.movieticket.repository.TicketLockRepo;
import com.movieticket.repository.UserRepository;

@Service
public class MovieServiceImpl implements MovieService {
	
	@Autowired
	UserRepository userRepo;
	@Autowired
	MovieDetailsRepo movDetRepo;
	@Autowired
	TicketLockRepo ticketLockRepo;
	@Autowired
	BookedTicketRepo bookedTicketRepo;

	@Override
	public MovResponse addUser(User user) throws MovException {
		Optional<User> userOp=userRepo.findByUsername(user.getUsername());
		Assert.isTrue(ObjectUtils.isEmpty(userOp),"User name not available");
			user.setRole(ObjectUtils.isEmpty(user.getRole())?"user":user.getRole());
			user.setStatus("active");
			user.setCreatedDate(new Date());
			userRepo.save(user);
		MovResponse response = new  MovResponse("User added successfully",true,user);
		return response;
	}

	@Override
	public List<MovieDetails> getMovies() throws MovException {
		List<MovieDetails> movieOp=movDetRepo.findAll();
		Assert.isTrue(!ObjectUtils.isEmpty(movieOp),"Movies not available");
		return movieOp;
	}

	@Override
	public MovResponse addMovie(MovieDetails details) {
		
		Assert.isTrue(!ObjectUtils.isEmpty(details.getMovieName()),"Enter valid movie name");
		movDetRepo.save(details);
		MovResponse response = new  MovResponse("Movie added successfully",true,details);
		return response;
	}

	@Override
	public synchronized MovResponse ticketBlock(MovieTicketDTO movieTicketDTO) {
		Optional<MovieDetails> movOp=movDetRepo.findByMovieNameIgnoreCase(movieTicketDTO.getMovieName());
		Assert.isTrue(movOp.isPresent(),"Movie not available");
		Assert.isTrue(!movieTicketDTO.getSeats().stream().anyMatch(predicate->(predicate.compareTo(1) < 0 || predicate.compareTo(100) > 0 )),"Please select valid seat");
		MovieDetails mov=movOp.get();
		boolean isBooked = false;
		if(!ObjectUtils.isEmpty(mov.getBookedTicket())) isBooked = mov.getBookedTicket().stream().anyMatch(mapper-> mapper.getBookedTicketDetails().stream().anyMatch(predicate->{
			return movieTicketDTO.getSeats().stream().anyMatch(predicate2->predicate2.equals(predicate.getSeatNo()));
		}));
		Assert.isTrue(!isBooked,"Seats are not available. Please select anyother seats");
		if(!ObjectUtils.isEmpty(mov.getTicketLock())) isBooked = mov.getTicketLock().stream().anyMatch(mapper-> (mapper.getTicketLockDetails().stream().anyMatch(predicate->movieTicketDTO.getSeats().stream().anyMatch(predicate2->predicate2.equals(predicate.getSeatNo())))
		) && isTicketLocked(mapper.getCreateDate()));
		Assert.isTrue(!isBooked,"Seats are not available. Please select anyother seats");
		TicketLock lock=new TicketLock();
		lock.setCreateDate(new Date());
		lock.setMovieDetails(mov);
		Set<TicketLockDetails> lockDet= new HashSet<TicketLockDetails>();
		movieTicketDTO.getSeats().stream().forEach(action->{
			TicketLockDetails lockDetails=new TicketLockDetails();
			lockDetails.setSeatNo(action);
			lockDetails.setTicketLock(lock);
			lockDet.add(lockDetails);
		});
		lock.setTicketLockDetails(lockDet);
		ticketLockRepo.save(lock);
		MovResponse response = new  MovResponse("Ticket has been locked for 2 minutes. Please use reference number to continue the bookings",true,lock.getId());
		return response;
	}

	@Override
	public MovResponse ticketConfirm(Integer referenceId) {
		Optional<TicketLock> ticketLockOp = ticketLockRepo.findById(referenceId);
		Assert.isTrue(ticketLockOp.isPresent(),"Not a valid reference id");
		TicketLock ticketLock=ticketLockOp.get();
		Assert.isTrue(isTicketLocked(ticketLock.getCreateDate()),"Booking expired. Please book again!");
		BookedTicket bookedTicket=new BookedTicket();
		bookedTicket.setCreateDate(new Date());
		bookedTicket.setMovieDetails(ticketLock.getMovieDetails());
		Set<BookedTicketDetails> bookedTicketDetails=new HashSet<BookedTicketDetails>(); 
		ticketLock.getTicketLockDetails().stream().forEach(action -> {
			BookedTicketDetails ticketDetails=new BookedTicketDetails(); 
			ticketDetails.setBookedTicket(bookedTicket);
			ticketDetails.setSeatNo(action.getSeatNo());
			bookedTicketDetails.add(ticketDetails);
		});
		bookedTicket.setBookedTicketDetails(bookedTicketDetails);
		bookedTicketRepo.save(bookedTicket);
		ticketLockRepo.delete(ticketLock);
		MovResponse response = new  MovResponse("Ticket has been booked and seat number "+bookedTicketDetails.stream().map(map->String.valueOf(map.getSeatNo())).collect(Collectors.joining(", ")),true,bookedTicket.getId());
		return response;
	}
	
	
	
	private boolean isTicketLocked(Date input) {
		Date date=new Date();
		DateTime dateTime=new DateTime(input);
		dateTime = dateTime.plusMinutes(2);
		System.out.println((date.compareTo(dateTime.toDate()) < 0) +" input  "+ date+" Increment date "+dateTime.toDate());
		return (date.compareTo(dateTime.toDate()) < 0);
		
	}

}
