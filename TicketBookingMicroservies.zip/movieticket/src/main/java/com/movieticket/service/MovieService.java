package com.movieticket.service;

import java.util.List;

import com.movieticket.dto.MovResponse;
import com.movieticket.dto.MovieTicketDTO;
import com.movieticket.entity.MovieDetails;
import com.movieticket.entity.User;
import com.movieticket.exception.MovException;

public interface MovieService {

	public MovResponse addUser(User user) throws MovException;

	public List<MovieDetails> getMovies() throws MovException;

	public MovResponse addMovie(MovieDetails details);

	public MovResponse ticketBlock(MovieTicketDTO movieTicketDTO);

	public MovResponse ticketConfirm(Integer referenceId);

}
