package com.movieticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.movieticket.entity.BookedTicket;

@Repository
public interface BookedTicketRepo extends JpaRepository<BookedTicket,Integer> {

}
