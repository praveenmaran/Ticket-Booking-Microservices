package com.movieticket.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.movieticket.entity.MovieDetails;

@Repository
public interface MovieDetailsRepo extends JpaRepository<MovieDetails,Integer>{
	
	Optional<MovieDetails> findByMovieNameIgnoreCase(String moviename);

}
