package com.movieticket.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.movieticket.entity.User;
import com.movieticket.repository.UserRepository;

@Component("userDetailsService")
public class CustomUserDetailsService implements UserDetailsService {
	
	@Autowired
	UserRepository userRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDetailsDTO detailsDTO=new UserDetailsDTO();
		Optional<User> userOp=userRepo.findByUsername(username);
		if(userOp.isPresent()) {
			User user = userOp.get();
		    detailsDTO.setUsername(user.getUsername());
		    detailsDTO.setPassword(user.getPassword());
		    List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			authorities.add(new SimpleGrantedAuthority(user.getRole()));
		    detailsDTO.setAuthorities(authorities);
		}
		return detailsDTO;
	}
}
