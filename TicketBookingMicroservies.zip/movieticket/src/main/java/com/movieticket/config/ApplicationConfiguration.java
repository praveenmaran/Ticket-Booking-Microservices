package com.movieticket.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfiguration {
	
	/*@Bean
    ServletRegistrationBean h2servletRegistration(){
        ServletRegistrationBean registrationBean = new ServletRegistrationBean(new WebServlet());
        registrationBean.addUrlMappings("/console/*");
        return registrationBean;
    }*/

}
