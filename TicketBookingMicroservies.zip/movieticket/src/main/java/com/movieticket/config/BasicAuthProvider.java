package com.movieticket.config;

import javax.annotation.Resource;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;


public class BasicAuthProvider implements AuthenticationProvider {

	@Resource(name = "userDetailsService")
	private CustomUserDetailsService authUserService;
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		UsernamePasswordAuthenticationToken userPassToken = (UsernamePasswordAuthenticationToken) authentication;
		String username = String.valueOf(userPassToken.getPrincipal());
		String password = String.valueOf(userPassToken.getCredentials());
		UserDetailsDTO detailsDTO=(UserDetailsDTO) authUserService.loadUserByUsername(username);
		if(detailsDTO.getUsername()==null) throw new AuthenticationServiceException("Invalid User");
		if(!detailsDTO.getPassword().trim().equals(password.trim())) throw new AuthenticationServiceException("Invalid Password");
		return new UsernamePasswordAuthenticationToken(detailsDTO, null, detailsDTO.getAuthorities());
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}
}
