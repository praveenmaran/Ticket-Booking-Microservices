package com.movieticket.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class MovieDetails {
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonIgnore
	private Integer id;
	@Column
	private String movieName;
	/*@Column
	private String seats;*/
	@Column
	@JsonIgnore
	private String status;
	@Temporal(TemporalType.TIMESTAMP)
	@Column
	@JsonIgnore
	private Date createdDate;
	
	@JsonIgnore
	@OneToMany(fetch=FetchType.EAGER, mappedBy="movieDetails")
	Set<TicketLock> ticketLock = new HashSet<TicketLock>(0);
	
	@JsonIgnore
	@OneToMany(fetch=FetchType.EAGER, mappedBy="movieDetails")
	Set<BookedTicket> bookedTicket = new HashSet<BookedTicket>(0);
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Set<TicketLock> getTicketLock() {
		return ticketLock;
	}
	public void setTicketLock(Set<TicketLock> ticketLock) {
		this.ticketLock = ticketLock;
	}
	public Set<BookedTicket> getBookedTicket() {
		return bookedTicket;
	}
	public void setBookedTicket(Set<BookedTicket> bookedTicket) {
		this.bookedTicket = bookedTicket;
	}
	
	

}
