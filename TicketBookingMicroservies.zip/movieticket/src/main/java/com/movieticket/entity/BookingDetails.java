package com.movieticket.entity;

public class BookingDetails {

}
