package com.movieticket.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value=Include.NON_NULL)
public class MovResponse implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8531103690859329095L;
	private String message;
	private boolean status;
	private Integer referenceId;
	private Object body;
	
	
	public MovResponse() {
		super();
	}
	public MovResponse(String message, boolean status) {
		super();
		this.message = message;
		this.status = status;
	}
	
	public MovResponse(String message, boolean status, Integer referenceId) {
		super();
		this.message = message;
		this.status = status;
		this.referenceId = referenceId;
	}
	public MovResponse(String message, boolean status, Integer referenceId, Object body) {
		super();
		this.message = message;
		this.status = status;
		this.referenceId = referenceId;
		this.body = body;
	}
	public MovResponse(String message, boolean status, Object body) {
		super();
		this.message = message;
		this.status = status;
		this.body = body;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Object getBody() {
		return body;
	}
	public void setBody(Object body) {
		this.body = body;
	}
	public Integer getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(Integer referenceId) {
		this.referenceId = referenceId;
	}
	
	
	
	

}
