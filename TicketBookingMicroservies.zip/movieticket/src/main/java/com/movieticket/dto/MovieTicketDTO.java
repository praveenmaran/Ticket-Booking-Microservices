package com.movieticket.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class MovieTicketDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4726066474615410299L;
	
	@NotBlank(message="Enter valid movie name")
	private String movieName;
	
	@Size(min=1,max=100,message="Please select valid seat")
	private Set<Integer> seats;
	
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public Set<Integer> getSeats() {
		return seats;
	}
	public void setSeats(Set<Integer> seats) {
		this.seats = seats;
	}
	
	
}
